/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package main1;

import java.util.Scanner;

/**
 *
 * @author user
 */
public class Main1 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        car car1= new car(2020, "mercedec", 2020, 1003.5, "red", 10);
        System.out.println(car1.toString());//print the details of car
        System.out.println("---------<<<<<<<<<<<>>>>>>>>>>>>----------");
        int inputUser;
        boolean done=false;
        while(!done){
            Scanner in = new Scanner(System.in);
            System.out.println("How may quantity you want to sale this car? ");
        if(in.hasNextInt()){
            inputUser=in.nextInt();
            if(inputUser<car1.getQuantity()){
                car1.setSell(inputUser);
                System.out.println("congratulations! you sale: " +inputUser+ " of the car");
                System.out.println("---------<<<<<<<<<<<>>>>>>>>>>>>----------");
                System.out.println(car1.toString());
                done=true;
            }else{
                System.out.println("Sorry!>>>we do not have this qauntity please input another quantity");
            }//end else in side
        }else{
            System.out.println("Sorry! you enter invalid number try again!");
        }//end if out side
        }//while     
        
    }//end main
    
}//end class
