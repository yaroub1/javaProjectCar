/*
*
*/
package main1;

/**
 *
 * @author user
 */
public class car {
    private int model;
    private String brand;
    private int year;
    private double price;
    private String color;
    private int quantity; 
    
    public car(int model, String brand, int year, double price, String color, int quantity){
        this.model=model;
        this.brand= brand;
        this.year=year;
        this.price=price;
        this.color=color;
        this.quantity=quantity;
    }
    
    public int getModel(){
        return model;
    }
    public String getBrand(){
        return brand;
    }
    public int geYrear(){
        return year;
    }
    public double getPrice(){
        return price;
    }
    public String getColor(){
        return color;
    }
    public int getQuantity(){
        return quantity;
    }
    public void setSell(int inputUser){
       quantity =quantity- inputUser;//set the quantity after selling 
    }
   public String toString(){
       return "the model of the car is: " + model+ 
               "\nthe brand of the car is: " +brand+
               "\nthe year of the car is: "+year+
               "\nthe price of the car is: "+price+ 
               "\nthe color of the car is:"+color+
               "\nthe quantity of the car is:"+quantity;
    }
    
    
}
